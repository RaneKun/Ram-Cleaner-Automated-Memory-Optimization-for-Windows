paste the "Scripts" folder to "C:" directory (root).
Open "Task Scheduler", click on Action -> Import task -> "Free up memory usage.xml" -> Ok.
after that when is asks to specify user name, specify it by typing your username.